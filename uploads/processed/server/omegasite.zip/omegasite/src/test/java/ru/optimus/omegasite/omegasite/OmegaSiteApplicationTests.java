package ru.optimus.omegasite.omegasite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OmegaSiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
