package ru.optimus.omegasite.omegasite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OmegaSiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(OmegaSiteApplication.class, args);
	}

}
